# imports 
import seaborn as sns 
import numpy as np 
import matplotlib.pyplot as plt


def plotHistogram(df, xcol, huecol): 
    sns.histplot(data=df, x=xcol, hue=huecol, multiple="stack")

def plot(df, xcol, ycol):
    sns.lineplot(data=df, x=xcol, y=ycol)

def plotScatter(df, xcol, ycol, huecol):
    sns.scatterplot(data=df, x=xcol, y=ycol, hue=huecol)

def plotScatterMatrix(df, huecol):
    sns.pairplot(data=df, hue=huecol)

def boxPlot(x):
    plt.figure(figsize=(15,7))
    sns.boxplot(x=x)
    plt.show()

def plotCorrelationMatrix1(df):
    # compute the correlation matrix
    corr = df.corr()

    # generate a mask for the upper triangle
    mask = np.triu(np.ones_like(corr, dtype=bool))

    # set up the matplotlib figure
    f, ax = plt.subplots(figsize=(11, 9))

    # generate a custom diverging colormap
    cmap = sns.diverging_palette(230, 20, as_cmap=True)

    # draw the heatmap with the mask and correct aspect ratio
    sns.heatmap(corr, mask=mask, cmap=cmap, vmax=.3, center=0, square=True, linewidths=.5, cbar_kws={"shrink": .5})

def plotCorrelationMatrix2(df):
    # compute a correlation matrix and convert to long-form
    corr_mat = df.corr().stack().reset_index(name="correlation")
    # draw each cell as a scatter point with varying size and color
    g = sns.relplot(
        data=corr_mat,
        x="level_0", y="level_1", hue="correlation", size="correlation",
        palette="vlag", hue_norm=(-1, 1), edgecolor=".7",
        height=10, sizes=(50, 250), size_norm=(-.2, .8),
    )

    # tweak the figure to finalize
    g.set(xlabel="", ylabel="", aspect="equal")
    g.despine(left=True, bottom=True)
    g.ax.margins(.02)
    for label in g.ax.get_xticklabels():
        label.set_rotation(90)
    for artist in g.legend.legendHandles:
        artist.set_edgecolor(".7")
               
def count_plot(data, x):
    data[x].value_counts()
    return sns.countplot(x=x,data=data,palette=["#FFD162"])