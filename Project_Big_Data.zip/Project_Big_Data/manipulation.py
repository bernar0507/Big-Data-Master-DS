import pandas as pd  
import numpy as np

def clean_df(df):
    """
    This function clean the remove rows that have:
        * fareamount that have negative amount or amounts > than 500
        * locations that are within NYC
    """
    return df[(df.fare_amount > 0)  & (df.fare_amount <= 500) &
             (df.pickup_datetime >= '2010-11-01') & 
             (df.pickup_datetime <= '2010-12-31') &
             (df.dropoff_datetime >= '2010-11-01') & 
             (df.dropoff_datetime <= '2010-12-31') &
             (df.passenger_count > 0) & (df.trip_distance > 0) &
             (df.tip_amount >= 0) & (df.total_amount > 0) &
             (df.surcharge >= 0) & (df.duration > 0)]

def clean_join_dfs(list_dataframes):
    """
    This function receives: 
        * list of dataframes
    returns:
        * dataframe with all the data and the data cleaned
    """
    new_df_list = []
    for df in list_dataframes:
        df['pickup_datetime']= pd.to_datetime(df['pickup_datetime'])
        df['dropoff_datetime']= pd.to_datetime(df['dropoff_datetime'])
        df["duration"] = (df["dropoff_datetime"]-df["pickup_datetime"]).astype('timedelta64[m]')
        df=clean_df(df)
        df['tip']=np.where(df['tip_amount'] > 0, 1, 0)  
        df=df[['passenger_count','duration','trip_distance','tip','tip_amount','total_amount']]
        new_df_list.append(df) 
        
    return new_df_list

def iqr_method(df):
    """IQR Score"""
    
    list_no_outliers_dfs = []  
    Q1 = df.quantile(0.25)
    Q3 = df.quantile(0.75)
    IQR = Q3 - Q1
    df_out = df[~((df < (Q1 - 1.5 * IQR)) |(df > (Q3 + 1.5 * IQR))).any(axis=1)]
        
    return df_out
    
def no_outlier_dfs(list_dataframes):
    
    list_df_no_outliers = []
    for df in list_dataframes:
        no_out_df = iqr_method(df)
        no_out_df2 = iqr_method(no_out_df)
        no_out_df3 = iqr_method(no_out_df2)
        no_out_df4 = iqr_method(no_out_df3)
        no_out_df5 = iqr_method(no_out_df4)
        no_out_df6 = iqr_method(no_out_df5)
        no_out_df7 = iqr_method(no_out_df6)
        no_out_df8 = iqr_method(no_out_df7)
        no_out_df9 = iqr_method(no_out_df8)
        no_out_df10 = iqr_method(no_out_df9)
        list_df_no_outliers.append(no_out_df10)
        
    return list_df_no_outliers
